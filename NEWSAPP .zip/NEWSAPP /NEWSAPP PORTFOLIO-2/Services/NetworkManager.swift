//
//  NetworkManager.swift
//  NEWSAPP PORTFOLIO-2
//
//  Created by Al John Rendon on 5/3/21.
//

import Foundation

class NetworkManager {
    let imageCache = NSCache<NSString, NSData>()
    static let shared = NetworkManager()
    private init(){}
    
    private let baseUrlString = "https://newsapi.org/v2/top-headlines?country=us"

    func getNews(completion: @escaping ([newsArticles]?) -> Void) {
        let urlString = "\(baseUrlString)&apiKey=\(ApiKey.key)"
        guard let url = URL(string: urlString) else {return}
        URLSession.shared.dataTask(with: url ) { (data, response, error) in
            guard error == nil, let data = data else {
                DispatchQueue.main.async {
                    completion(nil)
                }
                return
            }
            
            let NewsEnvelope = try? JSONDecoder().decode(newsEnvelope.self, from: data)
            NewsEnvelope == nil ? completion(nil) :
                DispatchQueue.main.async {
                    completion(NewsEnvelope?.articles)
                }
        }.resume()
        
    }
}
