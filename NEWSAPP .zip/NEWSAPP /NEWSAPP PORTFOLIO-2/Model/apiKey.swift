//
//  apiKey.swift
//  NEWSAPP PORTFOLIO-2
//
//  Created by Al John Rendon on 5/3/21.
//

import Foundation

struct ApiKey {
    static let key = "e0d01c995e064dafa538b5e9e7bed471"
}
