//
//  Model.swift
//  NEWSAPP PORTFOLIO-2
//
//  Created by Al John Rendon on 5/3/21.
//

import Foundation

struct newsEnvelope: Codable {
    let articles: [newsArticles]
}

struct newsArticles: Codable {
    let urlToImage: String?
    let url: String?
    let title: String?
    let description: String?
    let author: String?
    let publishedAt: String?
}
