//
//  HomeViewController.swift
//  NEWSAPP PORTFOLIO-2
//
//  Created by Al John Rendon on 4/3/21.
//

import UIKit
import SDWebImage
import SafariServices

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var newsTableView: UITableView!
    @IBOutlet weak var newsSearchBar: UISearchBar!

    var listOfNews = [newsArticles]() {
        didSet {
            self.newsTableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NetworkManager.shared.getNews {(list) in
            guard let l = list else { return }
            self.listOfNews = l
        }
    }
    
    //NAVBAR SETTINGS
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    //MARK: - TABLEVIEW DELEGATE
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listOfNews.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        showSafari(url: URL(string: listOfNews[indexPath.row].url ?? ""))
    }
    
    //MARK: - TABLEVIEW DATASOURCE
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = newsTableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as! NewsTableViewCell
        let news = listOfNews[indexPath.row]
        cell.newsTitle.text = news.title
        cell.newsDescription.text = news.description
        cell.newsAuthor.text = news.author
        cell.newsDate.text = news.publishedAt
        cell.newsImage.sd_setImage(with: URL(string: news.urlToImage ?? ""))
        return cell
    }
    
     //MARK: - HELPER METHODS

    fileprivate func showSafari(url: URL?) {
        guard let u = url else {return}
        let config = SFSafariViewController.Configuration()
        let vc = SFSafariViewController(url: u, configuration: config)
        
        present(vc, animated: true, completion: nil)
    }

}

//MARK: - EXTENSIONS

//extension HomeViewController: UISearchBarDelegate {
//    private func setUpSearchBar() {
//        func searchBarClicked(_ searchBar: UISearchBar, textDidChange searchText: String) {
//
//            if let everything = searchBar.text {
//                NetworkManager.getNews(description: everything)
//            }
//
//        }
//    }
//}


//let newsRequest = NetworkManager(everything: searchBarText)
//    newsRequest.getNews { [weak self] result in
//        switch result {
//        case .none:
//            print("error")
//        case .some(let newsUpdate):
//            self?.listOfNews = newsUpdate
//}
