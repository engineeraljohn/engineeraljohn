//
//  TitleViewController.swift
//  NEWSAPP PORTFOLIO-2
//
//  Created by Al John Rendon on 3/3/21.
//

import UIKit

class TitleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //SWIPE GESTURE
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction(swipe:)))
        leftSwipe.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(leftSwipe)
        
        //GRADIENT
        let newlayer = CAGradientLayer()
        newlayer.colors = [UIColor.darkGray.cgColor, UIColor.black.cgColor]
        newlayer.opacity = (0.8)
        newlayer.frame = view.frame
        
        view.layer.insertSublayer(newlayer, at: 1)
    }
    
    //NAVBAR SETTINGS
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        .lightContent
    }
    
}

//HELPER METHOD

extension UIViewController
{
    @objc func swipeAction(swipe:UISwipeGestureRecognizer) {
        switch swipe.direction.rawValue {
        case 2:
            performSegue(withIdentifier: "goLeft", sender: self)
        default:
            break
        }
    }
}
